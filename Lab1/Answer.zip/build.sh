#! /bin/bash
g++ main.cpp -o Main


